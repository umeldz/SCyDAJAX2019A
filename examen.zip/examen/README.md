LIGA.php 3
==============
Es un framework que proporciona una API para el acceso y control de la base de datos. Además se implementó un generador de código HTML a partir de entidades y registros de la base de datos; posee un enrutador muy fácil de usar, así como una extensión que permite fusionar archivos de Javascript y CSS para una carga más rápida de tus aplicaciones web.

Manual de uso y desarrollo: http://goo.gl/OOics
